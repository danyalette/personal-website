(function(window){
		function DoubleSlider(elem,callback){
		var color_elem =  _addChild(elem,"div",{className:"slider-bar-color"}); 
		var bar_elem =  _addChild(elem,"div",{className:"slider-bar", draggable:"false"}); 
		var left_knob =  _addChild(bar_elem,"div",{className:"knob", draggable:"false"}); 
		var right_knob =  _addChild(bar_elem,"div",{className:"knob", draggable:"false"}); 
	
		var container = bar_elem.getBoundingClientRect();
	
		this.left = new Knob(left_knob,container,0,this);
		this.right = new Knob(right_knob,container,0.99,this);
	
		this.getMin = function(){
			var min = this.left.val < this.right.val? this.left.val : this.right.val;
			return min; 
		}
		this.getMax = function(){
			var max = this.left.val > this.right.val? this.left.val : this.right.val;
			return max;
		}
		this.adjustColorBar = function(){
			color_elem.style.left = this.getMin() * container.width + "px"; 
			color_elem.style.width = (this.getMax() - this.getMin())*container.width + "px";
		}
		this.callback = function(){
			var vals = {max: this.getMax(), min: this.getMin()};
			callback(vals);
		}
		this.moveTo = function(min,max){
			this.left.move(min);
			this.right.move(max);
		}
	}
	function Knob(elem,container,val,obj){
		var that = this; 
		that.elem = elem;
		that.val = val;
		that.elem.style.left = container.width*val + "px";
		
		function dragging(ev){
			if ((ev.x < container.right)&&(ev.x > container.left)){
				that.elem.style.left = ev.x - container.left + "px"; 
				that.val = (ev.x - container.left)/container.width; 
				obj.adjustColorBar();
				obj.callback();
			}
		}
		function notDragging(){
			document.body.onmousemove = null;
		}
		
		this.elem.onmousedown = function(e){
			e.preventDefault();
			document.body.onmousemove = dragging;
		}
		document.body.onmouseup = notDragging; 
		this.move = function(val){
			if ((val > 1)||(val < 0)){
				console.log("moveTo(min,max) expects values between 0 and 1");
				return;
			}
			var left = val*container.width +  "px"; 
			this.val = val;
			this.elem.style.left = left; 
			obj.adjustColorBar();
			obj.callback();
		}
	}
	
	
	
	window.DoubleSlider = DoubleSlider;
	
})(window);
