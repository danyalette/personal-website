
function _addChild(_parent,_type,_attr){
	var elem = document.createElement(_type);
	for (attr in _attr){
		elem[attr] = _attr[attr];
	}
	_parent.appendChild(elem);
	return elem; 
}

function _1(name){
	if (document.querySelector(name)) return document.querySelector(name);
	if (document.getElementById(name)) return document.getElementById(name);
	if (document.getElementsByClassName(name)) return document.getElementsByClassName(name)[0]; 
	return false;
}

function __(selector){
	var all = [].slice.call(document.querySelectorAll(selector), 0); 
	if (all && all.length > 0) return all;
	return false; 
}

function _v(parent, child_selector){
	var exid = parent.id;
	var id = make_id(5);
	parent.id = id;
	var children = __("#" + id + " " + child_selector);
	parent.id = exid;
	if (children && children.length > 0) return children;
	return false;  
}


function _p(child, parent_selector){
	var exid = child.id;
	var id = make_id(5);
	child.id = id;
	var children = __(parent_selector + " #" + id);
	child.id = exid;
	if (children && children.length > 0) return true;
	return false;  
}

function _A(el,cls){
    while ((el = el.parentElement) && !el.classList.contains(cls));
    return el;
}; 


function make_id(n)
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    for( var i=0; i < n; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}
function click_on_class(e,classname){
	var path = e.path;
	var in_path = false; 
	for(node in path){
		if ((path[node].className)&&(path[node].className.indexOf(classname) >= 0)) in_path = true;
	}; 
	return in_path; 
}



